﻿Public Class Frm_Clientes
    Private Sub Frm_Clientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GestorClientes asd = New GestorClientes();

    End Sub
End Class
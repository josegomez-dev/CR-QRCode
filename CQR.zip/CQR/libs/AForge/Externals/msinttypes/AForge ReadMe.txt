The folder contains files from "msinttypes" project, which allow compiling C99 compliant projects in MSVC.
http://code.google.com/p/msinttypes/
